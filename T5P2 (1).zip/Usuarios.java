import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("1ec8d692-dd2b-459f-934e-45d7f502ccb7")
public class Usuarios {
    @objid ("7ae21dde-9a59-43d1-8ceb-7961d989a12c")
    private String NIF;

    @objid ("c560cda6-c77d-48ec-8ad2-f1df2ac5457e")
    private String Nombre;

    @objid ("f75967eb-2524-430f-a068-ddf440de34c4")
    private Date Fecha_De_Nacimiento;

    @objid ("3b2c7e21-3983-4a7c-b55f-551a61730142")
    public Prestamos ;

}
