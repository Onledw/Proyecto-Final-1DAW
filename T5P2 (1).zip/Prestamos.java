import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("2c312e0b-3de3-4c4a-9849-43d5fd875368")
public class Prestamos {
    @objid ("3125ca38-8c99-46ce-8b04-846fcb56954d")
    private int Codigo_D;

    @objid ("2c5f5cd3-1072-4a34-946a-46f85ccb0531")
    private String NIF;

    @objid ("dfe377d4-56d9-43d9-be44-f35e5cf3ad98")
    public List<Usuarios> usuarios = new ArrayList<Usuarios> ();

    @objid ("b91b3ae7-c278-4888-92b1-2d39434a3624")
    public Documento ;

    @objid ("06e80fa9-e60e-417c-b5d5-df5f17eb54e7")
    public int getCodigo_D() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.Codigo_D;
    }

    @objid ("66a88e26-e2eb-41bc-ac88-2deff750d264")
    public void setCodigo_D(final int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.Codigo_D = value;
    }

    @objid ("4663f447-75f5-47c8-9fe7-1016ba374b40")
    public String getNIF() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.NIF;
    }

    @objid ("1f3cbf54-dd0a-48bb-b795-9c2c688e1643")
    public void setNIF(final String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.NIF = value;
    }

    @objid ("4b5ac5d1-e62e-41a0-8b39-30a0ce2306c1")
    public Documento get() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.;
    }

    @objid ("7eeade4d-04c6-480b-8501-85a7b216f533")
    public void set(final Documento value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this. = value;
    }

    @objid ("3d70ca0b-ea11-43d1-a5f9-fea4ac8a00c1")
    public List<Usuarios> getUsuarios() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.usuarios;
    }

    @objid ("5588fe58-83db-4ded-afc7-65f9eba813a2")
    public void setUsuarios(final List<Usuarios> value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.usuarios = value;
    }

}
