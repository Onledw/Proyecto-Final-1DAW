import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("2df42a1e-587c-4f1a-a393-77b2729023b2")
public class Documento {
    @objid ("b5dbbf94-f40e-4a5b-aed0-8c2bee7d1043")
    private int Codigo_D;

    @objid ("8324f269-3d0c-4bf5-af2d-12a2b2ff82c7")
    private String Cod_C;

    @objid ("3ff14a2d-14f4-4cf7-b361-41133c222146")
    public List<Prestamos> prestamos = new ArrayList<Prestamos> ();

    @objid ("c36a5296-4b5e-4aad-beb3-dd30ab3c52c9")
    public static Categoria categoria;

    @objid ("b839b9a9-27b1-4b57-b7f8-05668ee37e4a")
    public int getCodigo_D() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.Codigo_D;
    }

    @objid ("2a3c1b0b-deeb-40d7-8447-fb765762c885")
    public void setCodigo_D(final int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.Codigo_D = value;
    }

    @objid ("e16fa1cb-d402-417a-a7ed-be96478d1d06")
    public String getCod_C() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.Cod_C;
    }

    @objid ("610ad881-0548-4684-bd19-d487b4cb6b49")
    public void setCod_C(final String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.Cod_C = value;
    }

    @objid ("24c5faf3-fa53-4165-9805-eeeb310f246a")
    public List<Prestamos> getPrestamos() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.prestamos;
    }

    @objid ("74de669c-d128-48d6-a256-780ec6aa4764")
    public void setPrestamos(final List<Prestamos> value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.prestamos = value;
    }

    @objid ("74d98f4c-e946-4dfe-b146-ca1a346e319e")
    public void setCategoria(final Categoria value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.categoria = value;
    }

    @objid ("65eafcf4-8e41-4b9d-84a5-2563d461ec7d")
    public Categoria getCategoria() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.categoria;
    }

}
