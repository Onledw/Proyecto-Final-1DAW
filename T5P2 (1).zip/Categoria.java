import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("ee9f327e-1065-4a54-a2e5-ee45f4edec01")
public class Categoria {
    @objid ("62ae49ef-60a6-4c6f-a6b5-bdeab46ea31a")
    private String Cod_C;

    @objid ("6f626b8d-e00a-46ec-afac-019b6715da6a")
    public List<Documento>  = new ArrayList<Documento> ();

    @objid ("6db597bf-2ca3-4df3-88d7-2f58ffa6148d")
    public String getCod_C() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.Cod_C;
    }

    @objid ("1adc0a26-a4c1-463c-b1f6-2cfa9d30f0db")
    public void setCod_C(final String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.Cod_C = value;
    }

}
