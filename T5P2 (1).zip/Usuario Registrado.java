import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("801abf1b-b26e-4465-9849-c7888dfa8643")
public class Usuario Registrado extends Usuarios {
    @objid ("a51fc4b5-a7a5-47b2-8c89-65dd9506cca3")
    private String Numero_De_Prestamos;

    @objid ("1fc8d890-9f1b-4b74-9723-13a4339c57b1")
    public String getNumero_De_Prestamos() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.Numero_De_Prestamos;
    }

    @objid ("ccab57c3-1f6f-4bcf-a083-a0a4c101849b")
    public void setNumero_De_Prestamos(final String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.Numero_De_Prestamos = value;
    }

}
