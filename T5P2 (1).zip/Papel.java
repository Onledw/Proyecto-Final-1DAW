import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("66e1f3ae-a2a3-45b6-9cc4-d4c59dceb31b")
public class Papel extends Documento {
    @objid ("00e6a2d6-c013-4bfa-9c9d-3d6aee583f27")
    private String Autor;

    @objid ("68d4bb90-62dd-44c3-801d-f12d421684a9")
    public String getAutor() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.Autor;
    }

    @objid ("acc6e527-8dfa-4eb0-befb-21e4938d367f")
    public void setAutor(final String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.Autor = value;
    }

}
