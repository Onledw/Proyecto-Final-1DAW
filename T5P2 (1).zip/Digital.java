import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("09e9847a-9ac4-444b-a988-b33620d328ac")
public class Digital extends Documento {
    @objid ("9c714cb6-59e7-48f4-9974-4681690a5b48")
    private int URL;

    @objid ("965f7d0f-f5b9-4306-8ad7-1bcb5a406e34")
    public int getURL() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.URL;
    }

    @objid ("a55d4b1b-d17e-4e0b-8e8c-900dc46f7292")
    public void setURL(final int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.URL = value;
    }

}
