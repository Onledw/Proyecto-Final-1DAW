import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("73f2e5aa-a472-404a-bdfd-13e5dc427c66")
public class Usuario Admin extends Usuarios {
    @objid ("b5059a28-5e08-4453-950c-517ffecc9f38")
    private String Permisos;

    @objid ("c67aa85c-d3ac-46b1-8666-667102754d49")
    public List<Usuario Admin> usuario Admin = new ArrayList<Usuario Admin> ();

    @objid ("8f0302fa-a004-4815-aa38-6ad6b33b3a35")
    public void setUsuario Admin(final List<Usuario Admin> value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.usuario Admin = value;
    }

    @objid ("e8ba3152-7939-43c7-b797-66478cebc01a")
    public List<Usuario Admin> getUsuario Admin() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.usuario Admin;
    }

    @objid ("c2deb44f-2f81-47c9-b352-6639b02a674e")
    public String getPermisos() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.Permisos;
    }

    @objid ("9045da19-84a4-46af-a24b-cad35bc22d39")
    public void setPermisos(final String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.Permisos = value;
    }

}
